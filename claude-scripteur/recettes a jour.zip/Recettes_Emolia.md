# RECETTES ÉMOLIA — UNIVERS CARESSE

**Date :** 19 mars 2026
**Statut :** public

---

## LIGNE : BAUME À LÈVRES

**Nb unités :** 18 | **Cure :** aucune

---

### BAISER FRUITÉ

**HEX :** #5A1C37

**Recette :**
- 20g cire de carnauba
- 30g beurre de karité
- 25g huile de calendula
- 25g huile de jojoba
- 14g beurre de mangue
- 2-4g allantoine
- 1.5g vitamine E (30 gouttes)
- 0.6g arôme de fraise
- 0.6g arôme cerise
- 1.5g mica rose-rouge

**Notes :** Colore les lèvres

**Version courte :** La douceur des fruits rouges, un brillant qui fait tout dire.

**Version longue :** Ferme les yeux et laisse-toi porter par les vergers en fleurs ! Fraise et cerise se mêlent en un duo gourmand et envoûtant, pendant que l'huile de ricin enveloppe tes lèvres d'un voile glossy irrésistible. Un baume qui hydrate, protège et donne envie d'être embrassée.

---

### BAUME LÈVRES ENFANT (-6 ans)

**Nb unités :** 18
**Collections secondaires :** Petit Nuage
**Nuage fraise (été) :** #9C1E45 / #90E145 ⚠️ à confirmer
**Petit nuage douillet (hiver) :** #519A9C

**Version été :**
- 15g cire d'abeille
- 30g beurre de karité
- 25g huile de tournesol oléique
- 20g huile de coco
- 15g beurre de mangue
- 1g vitamine E (20 gouttes)
- 0.5g arôme de fraise

**Version hiver :**
- 20g cire d'abeille
- 35g beurre de karité
- 25g huile de tournesol oléique
- 20g huile de coco
- 15g beurre de mangue
- 1g vitamine E (20 gouttes)
- 0.5g arôme de fraise

**Notes :** Zéro HE, Zéro Mica, Comestibles et non toxiques

**Nuage fraise :** Doux comme un nuage, sucré comme une fraise — un baume sécuritaire pour les petites lèvres.

**Nuage fraise (version longue) :** Les petites lèvres méritent les meilleurs soins. Nuage Fraise est formulé sans huile essentielle, sans mica, avec des ingrédients doux et non toxiques pensés pour les tout-petits. Son arôme de fraise sucrée transforme chaque application en petit moment gourmand. Le karité nourrit, le beurre de mangue protège, la cire d'abeille scelle la douceur. Un baume aussi innocent qu'un sourire d'enfant.

**Petit nuage douillet :** Un câlin pour les petites lèvres quand le froid arrive — doux, sécuritaire et réconfortant.

**Petit nuage douillet (version longue) :** L'hiver est rude, même pour les plus petits. Petit Nuage Douillet est une version hivernale plus enveloppante, avec davantage de cire d'abeille et de karité pour protéger les lèvres fragilisées par le froid. Toujours sans huile essentielle, sans mica, formulé pour les peaux délicates des tout-petits. Son arôme de fraise reste là, fidèle et rassurant, comme un nuage chaud rien que pour eux.

---

### FRAISE ET BASILIC

**HEX :** #B60F31

**Recette :**
- 22g huile de coco
- 30g cire d'abeille
- 30g beurre de mangue
- 5g vitamine E
- 10g sirop de fraise
- 0.5g HE basilic

**Notes :** 5g vitamine E = 1 c. à thé / 10g sirop de fraise = 2 c. à thé

**Version courte :** L'audace d'un duo inattendu, la douceur d'un instant gourmand.

**Version longue :** Qui aurait pensé marier la fraise et le basilic ? Et pourtant, la douceur sucrée de la fraise rencontre le caractère herbacé du basilic pour créer quelque chose d'unique et d'inoubliable. Un baume qui surprend, séduit et nourrit à chaque application.

---

### LAVANDE - ROMARIN

**HEX :** #908ED3

**Recette :**
- 22g huile de coco
- 30g cire d'abeille
- 30g beurre de mangue
- 1g vitamine E (2 capsules)
- 0.6g HE lavande vraie (12 gouttes)
- 0.6g HE romarin (12 gouttes)
- 6 gouttes couleur lavande

**Notes :** 100% naturel, 100% essentiel

**Version courte :** La sérénité de la lavande, la vigueur du romarin. La Provence dans un baume.

**Version longue :** Fermez les yeux et respirez. La lavande apaise, le romarin vivifie. Ensemble ils forment un duo intemporel qui nourrit les lèvres en profondeur et enveloppe les sens d'une douceur florale et herbacée. 100% naturel, 100% essentiel.

---

### MENTHE POIVRÉE

**HEX :** #90FAD3

**Recette :**
- 22g huile de coco
- 30g cire d'abeille
- 30g beurre de mangue
- 5g vitamine E
- 5g arôme naturel de menthe poivrée
- 0.5g HE menthe poivrée (10 gouttes)
- 6 gouttes couleur vert

**Notes :** 5g vitamine E = 1 c. à thé / 5g arôme naturel de menthe poivrée = 1 c. à thé / Vérifier nom — Menthe poivrée ou Frisson de menthe ?

**Version courte :** Un frisson de fraîcheur, même en plein hiver.

**Version longue :** Vive, pétillante et sans compromis, menthe poivrée réveille les lèvres et les sens d'un seul geste. Son arôme naturel et ses huiles essentielles créent une sensation de fraîcheur immédiate qui persiste longtemps. Le froid dehors, la fraîcheur dedans.

---

### SOUFFLE D'ÉTÉ

**HEX :** #F1FFBB

**Recette :**
- 18g cire de carnauba
- 30g beurre de karité
- 24g huile de calendula
- 24g huile de ricin
- 18g huile de coco
- 2.4g allantoine
- 1.8g vitamine E (36 gouttes)
- 2g mica perlé blanc
- 2 gouttes HE menthe poivrée

**Instructions :** Fondre cire. Ajouter huile et beurre. Hors feu, ajouter allantoine en remuant bien. Ajouter vitamine E, mica et HE.

**Notes :** Nacré blanc sans trop.

**Version courte :** Un souffle de fraîcheur pour des lèvres réparées par le soleil.

**Version longue :** Quand le soleil brûle et dessèche, Souffle d'été prend soin de tes lèvres avec douceur. Un baume réparateur et nacré, enrichi en karité, calendula et allantoine, qui apaise les gerçures et redonne éclat et légèreté. Une subtile fraîcheur de menthe, comme une brise qui passe.

---

### SOUFFLE D'HIVER

**Recette :**
- 26g cire d'abeille
- 26g huile de coco
- 26g beurre de karité
- 13g huile d'amande douce
- 0.4g HE eucalyptus globuleux (8 gouttes)
- 0.3g HE menthe poivrée (6 gouttes)
- 0.2g HE ravintsara (4 gouttes)
- 5 gouttes colorant bleu
- 2.5g vitamine E

**Instructions :** Appliquer sur les lèvres et sous les narines. Conservation 1 an.

**Notes :**

**Version courte :** Un souffle chaud qui libère, répare et protège au cœur de l'hiver.

**Version longue :** Quand le froid mord et que l'air se fait lourd, Souffle d'hiver veille. Ses vapeurs d'eucalyptus, de menthe et de ravintsara dégagent les narines et apaisent les lèvres gercées. Un baume qui soigne autant qu'il réconforte.

---

### VENT FRAIS

**HEX :** #609C6A

**Recette :**
- 20g cire de carnauba
- 30g beurre de karité
- 25g huile de calendula
- 25g huile de jojoba
- 12g beurre de cacao
- 2.4g allantoine
- 1.5g vitamine E (30 gouttes)
- 0.15g HE menthe poivrée (3 gouttes)
- 0.1g HE tea tree (2 gouttes)
- 0.1g HE eucalyptus radiata (2 gouttes)

**Notes :** Déconseillé aux femmes enceintes et enfants de moins de 6 ans

**Version courte :** La nature à l'état pur, sur tes lèvres.

**Version longue :** Inspiré des grands espaces et des matins clairs. Vent frais est un baume sans artifice, pour elle comme pour lui. Menthe, eucalyptus et tea tree se fondent en une sensation de fraîcheur immédiate et végétale. Mat, léger, essentiel, comme une bouffée d'air pur en plein été.

---

## LIGNE : BAUME CORPOREL

**Nb unités :** ⚠️ à confirmer | **Cure :** aucune

---

### EFFLUVE APAISANT

**HEX :** #E7B539

**Recette :**
- 50g huile de coco
- 50g beurre de karité
- 10g cire d'abeille
- 0.75g HE eucalyptus globuleux (15 gouttes)
- 0.35g HE camphrier (7 gouttes)
- 0.50g HE menthe poivrée (10 gouttes)
- 0.50g HE cèdre Atlas (10 gouttes)
- 0.50g HE ravintsara (10 gouttes)
- 0.25g HE térébenthine (5 gouttes)

**Notes :**

**Version courte :** Un baume aromatique qui dégage, réchauffe et réconforte — le souffle de l'hiver apprivoisé.

**Version longue :** Un souffle clair qui libère la respiration, une chaleur douce qui réconforte. Effluve apaisant dépose sur la peau un nuage aromatique qui apaise l'hiver.

---

### PETIT BOUCLIER

**HEX :** #519A9C
**Collections secondaires :** Petit Nuage

**Recette :**
- 50g beurre de karité
- 40g huile de coco
- 10g cire d'abeille
- 2g maximum fragrance poudre de bébé

**Notes :** Les zones comme les fesses sont plus sensibles / Pour utilisation externe seulement

**Version courte :** Un voile protecteur tout en douceur, pour les petites peaux qui ont besoin d'être chouchoutées.

**Version longue :** Un voile de douceur qui enveloppe la peau d'un confort rassurant, comme un nuage qui veille. Pour les petits bobos du quotidien, la peau sèche, les zones irritées, les joues rougies par le froid.

---

## LIGNE : BOMBES DE BAIN ADULTE

**Nb unités :** 3 | **Cure :** aucune

**Recette de base :**
- 115g bicarbonate de soude
- 55g fécule de maïs
- 55g acide citrique
- 50g sel d'Epsom
- 10g eau déminéralisée
- 0.50g HE (10 gouttes)
- 45g huile d'amande douce
- 6g fleurs si désiré

**Notes :** 10g eau = 2 c. à thé / 45g huile d'amande douce = 3 c. à table / 6g fleurs = 1 c. à table

**Texte général :** L'effervescence du bien-être. À base de bicarbonate, fécule et sel d'Epsom, elles transforment votre bain en rituel apaisant. Détente musculaire, peau adoucie et moment suspendu dans un nuage parfumé.

---

### BORÉAL

**HEX :** #7F6811
**Collections secondaires :** LUI

**Additifs :**
- 0.50g HE petitgrain
- 0.50g HE cèdre feuilles
- 0.50g HE palmarosa
- Musc blanc
- Colorant ⚠️ à confirmer avec Chantal

**Version courte :** Le grand air du Nord dans un bain effervescent — bois, verdure et musc pour une détente profonde.

**Version longue :** Fermez les yeux et laissez l'effervescence vous emporter. Boréal plonge le bain dans une atmosphère forestière et nordique — le petitgrain apporte sa fraîcheur verte, le cèdre ancre dans le boisé, la palmarosa adoucit. Une bulle d'air pur qui détend les muscles et apaise l'esprit, comme une nuit tranquille sous les étoiles du Nord.

---

### BRISE DES LAGUNES

**HEX :** #3EAF85
**Collections secondaires :** LUI

**Additifs :**
- 0.50g brise de mer
- 0.50g cèdre bleu
- Colorant ⚠️ à confirmer avec Chantal

**Version courte :** Une escapade aquatique — la brise marine et le cèdre bleu pour un bain qui sent l'horizon.

**Version longue :** Laissez l'effervescence dessiner des lagunes dans votre bain. Brise des lagunes capture l'air salin des eaux turquoise, le souffle tiède du cèdre bleu qui s'attarde sur la peau. Une bulle d'évasion qui transporte loin — là où l'eau est claire, le ciel ouvert et le temps suspendu.

---

### DÉLICAT

**HEX :** #AF99A4

**Additifs :**
- 0.50g huile aromatique pivoine
- 0.50g HE lavande vraie
- 0.50g HE thé vert
- Colorant ⚠️ à confirmer avec Chantal

**Version courte :** Pivoine, lavande et thé vert — une effervescence florale toute en douceur.

**Version longue :** Délicat invite la pivoine et la lavande à danser dans votre bain. L'effervescence libère un voile floral subtil et apaisant, pendant que le thé vert protège la peau en douceur. Un moment suspendu, élégant et féminin, pour les soirs où l'on mérite qu'on prenne soin de soi.

---

### DOUCE PENSÉE

**HEX :** #E76877

**Additifs :**
- 0.50g HE géranium rosat
- 0.50g HE ylang-ylang
- Colorant ⚠️ à confirmer avec Chantal

**Version courte :** Géranium rosat et ylang-ylang — une effervescence florale chaude et enveloppante.

**Version longue :** Douce pensée transforme le bain en un rituel floral et sensuel. Le géranium rosat équilibre, l'ylang-ylang enveloppe d'une chaleur presque tropicale. L'effervescence libère ces deux parfums en un nuage doux et généreux qui s'attarde sur la peau. Un bain qu'on s'offre quand les mots ne suffisent pas.

---

### NUAGE DE LAVANDE

**HEX :** #7F68CA

**Additifs :**
- 0.50g HE lavande vraie
- Colorant ⚠️ à confirmer avec Chantal

**Version courte :** La lavande à l'état pur — une effervescence douce pour un bain tout en quiétude.

**Version longue :** Nuage de lavande n'a pas besoin de complices. La lavande vraie se déploie dans l'effervescence, enveloppe le bain d'un voile apaisant et profond. L'eau devient un champ de lavande, le soir. Pour les corps fatigués et les esprits qui cherchent le calme.

---

### VANILLE ET CITRON

**HEX :** #FFF8DC

**Additifs :**
- 0.50g HE citron
- 0.50g arôme de vanille
- Colorant ⚠️ à confirmer avec Chantal

**Version courte :** La douceur de la vanille rencontre le pétillement du citron — un bain gourmand et lumineux.

**Version longue :** Vanille et citron, c'est le duo inattendu qui réchauffe et éveille à la fois. L'effervescence libère la douceur crémeuse de la vanille et l'éclat vif du citron dans un nuage gourmand et enveloppant. Un bain qui sent bon, qui fait du bien, et qui donne envie de rester dans l'eau juste un peu plus longtemps.

---

## LIGNE : BOMBES DE BAIN PETIT NUAGE (enfant)

**Nb unités :** 24 | **Cure :** aucune
**Collections secondaires :** Petit Nuage

**Recette de base :**
- 240g bicarbonate de soude
- 120g acide citrique
- 120g fécule de maïs
- 26g huile d'amande douce
- 13g beurre de karité fondu

**Notes :** Pas de sel d'Epsom ni de HE / 26g huile d'amande douce = 2 c. à table / 13g beurre de karité fondu = 1 c. à table

**Texte général :** L'heure du bain devient une fête. Ces bombes douces et colorées transforment l'eau en une bulle de tendresse parfumée. Sans huile essentielle, sans sel d'Epsom, formulées pour les peaux délicates des tout-petits. Juste de la douceur, de l'effervescence et beaucoup de sourires.

---

## LIGNE : SAVON EXFOLIANT

**Nb unités :** 9 | **Cure :** 28 jours

---

### BRUME DE ROSÉE

**HEX :** #9EBD7C

**Recette de base :**
- 325g huile de tournesol oléique
- 260g huile de coco
- 65g beurre de karité
- 184g eau déminéralisée
- 92g NaOH

**Additifs :**
- 16g HE menthe poivrée
- 9 luffa (1 par savon)
- Micas à fleurs bleues ⚠️ quantité à confirmer
- Couleur vert grass

**Notes :**

**Version courte :** Le luffa réveille, la menthe vivifie. Une fraîcheur verte pour une peau neuve.

**Version longue :** Comme une promenade matinale après la pluie, ce savon exfoliant capture la fraîcheur de l'aube. Le luffa naturel caresse la peau tandis que la menthe poivrée réveille les sens. Un nuage vert tendre, promesse d'une douceur vivifiante.

---

## LIGNE : SAVON À RASER

### L'INSTANT DU BARBIER

**HEX :** #AA7513
**Collections secondaires :** Saponica
**Cure :** 6 semaines

**Recette (1 kilo) :**
- 300g huile de coco
- 150g huile de ricin
- 350g huile d'olive vierge
- 200g beurre de karité
- 136g NaOH
- 340g eau déminéralisée
- 2g soie de tussah
- 2g vitamine E
- 20g HE lavande vraie
- 6g HE menthe poivrée
- 10g HE cèdre Atlas

**Notes :**

**Version courte :** Un savon qui transforme le rasage en rituel. Une mousse onctueuse qui prend soin du poil et de la peau, du premier geste au dernier.

**Version longue :** Ce savon enveloppe le visage d'une crème dense et soyeuse qui prépare le poil, protège la peau et invite la lame à glisser sans résistance. Le parfum, lui, raconte un paysage. La lavande ouvre le souffle, calme, recentre. La menthe arrive comme une brise fraîche sur la peau encore chaude. Puis le cèdre s'installe, profond, boisé, masculin. Il reste longtemps, comme souvenir d'une forêt traversée à l'aube. Chaque pain est coulé à froid, lentement saponifié, longuement séché. Le temps fait partie de la recette.

---

## LIGNE : HUILE À BARBE

### L'ÉLIXIR DU MATIN

**HEX :** #C57513
**Collections secondaires :** LUI
**Rendement :** 6 x 50ml

**Recette :**
- 138g huile d'amande douce
- 66g huile d'argan
- 77g huile de ricin
- 3g vitamine E
- 1.7g HE lavande vraie
- 0.9g HE cèdre Atlas
- 0.5g HE menthe poivrée

**Notes :**

**Version courte :** Trois huiles nobles, un souffle de lavande, un fond de cèdre. Une huile légère qui nourrit, assouplit et sublime la barbe, du premier jour à la barbe accomplie.

**Version longue :** La barbe mérite qu'on s'en occupe. L'Élixir du matin est une alliance de trois huiles soigneusement choisies : l'amande douce qui fond sur la peau sans laisser de trace, l'argan précieux qui apporte brillance et douceur au poil, le ricin qui nourrit et encourage une pousse saine et dense. Son parfum prolonge le rituel du rasage, les mêmes huiles essentielles que le savon. Un accord pensé pour que les deux se répondent matin après matin. Quelques gouttes dans la paume. On réchauffe. On pose. Discret, élégant, juste ce qu'il faut.
