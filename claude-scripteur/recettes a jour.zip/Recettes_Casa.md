# RECETTES CASA — UNIVERS CARESSE

**Date :** 19 mars 2026
**Cure :** aucune | **Statut :** public

---

## TEXTE DE COLLECTION

CASA, c'est la même philosophie que pour votre peau — appliquée à votre maison. Des produits pensés avec les mêmes exigences : ingrédients choisis, efficacité réelle, sans compromis. Parce que prendre soin de son intérieur, c'est aussi prendre soin de soi.

Un cake vaisselle qui dégraisse sans agresser les mains, une eau de linge qui dépose sa douceur sur chaque fibre. Et quand le travail est fait — une bruine qui parfume l'air, une chandelle qui pose l'ambiance. Le quotidien, sublimé.

---

## LIGNE : BOUGIE LUMINA

**Nb unités :** selon format
**Notes :** La quantité par lot dépend du format de contenant choisi lors de la recette.

### RECETTE DE BASE

- 1000g cire de soya
- 80g essence au choix

### PARFUMS DISPONIBLES

| Bougie | HEX |
|--------|-----|
| Club privé | #6B5229 |
| Feu d'automne | #FC6B33 |
| Lessive fraîche | #F1FFEF |
| Nuage de lavande | #7F68CA |
| Pivoine et Poire | #A26B83 |

### TEXTE DE COLLECTION

**P1 :** La douceur en lumière. Ces chandelles artisanales prolongent l'univers olfactif de nos savons dans une danse de flammes apaisantes. Fabriquées à partir de cire de soya, elles diffusent leurs fragrances naturelles sans fumée nocive.

**P2 :** Retrouvez les parfums signature de la collection Saponica ainsi que des créations exclusives, dans deux formats pensés pour tous les moments. Coulées à la main en petites séries, ces chandelles transforment chaque pièce en un cocon sensoriel. Une lumière douce, un parfum qui caresse l'air, un instant suspendu.

---

## LIGNE : BRUINE D'AMBIANCE

**Nb unités :** 5 / format : 50 ml
**HEX :** ⚠️ à confirmer selon fragrances

### RECETTE DE BASE

- 54g alcool à 70%
- 152g eau déminéralisée
- 0.75g HE au choix

### PARFUMS DISPONIBLES

| Bruine | Fragrance |
|--------|-----------|
| Agrumes et romarin | |
| Lessive fraîche | |
| Poire | |
| Lavande | |
| Brise des lagunes | |

**Notes :** Recette originale : 60 ml alcool 70%, 190 ml eau déminéralisée, 15 gouttes HE

**Version courte :** Un souffle délicat qui transforme l'air de votre intérieur. Fragrances naturelles sur eau déminéralisée, pour un voile olfactif subtil et apaisant.

**Version longue :** L'atmosphère en bouteille. Ce spray délicat transforme instantanément l'air de votre intérieur en une invitation à la détente. Formulée à base d'eau déminéralisée et de fragrances naturelles, la bruine d'ambiance enveloppe chaque pièce d'un voile olfactif subtil et éphémère. Une impulsion, et l'espace se métamorphose.

---

## LIGNE : CAKE VAISSELLE

### ÉCLAT CITRONNÉ

**HEX :** #FFF816
**Nb unités :** 1

**Recette pour un cake :**
- 129g SCI
- 12g vinaigre blanc
- 38g eau déminéralisée
- 18g cristaux de soude
- 2g HE citron

**Notes :**

**Version courte :** Un cake dégraissant au citron, efficace et naturel. Une longévité exceptionnelle qui remplace plusieurs flacons.

**Version longue :** Dans la continuité de notre philosophie, Éclat citronné apporte la même authenticité à l'évier. Ce pain solide mousse généreusement au contact de l'eau et de l'éponge, dégraisse sans effort et ne laisse aucune trace. Sa texture ferme et compacte lui confère une longévité remarquable. Le citron nettoie, purifie et laisse un parfum frais et lumineux. La simplicité qui lave, qui dure, qui respecte.

---

## LIGNE : EAU DE LINGE

**Nb unités :** 1 / format : 500 ml
**HEX :** ⚠️ à confirmer selon fragrances

### RECETTE DE BASE

- 99g alcool à 70%
- 304g eau déminéralisée
- 4-5g HE au choix (80-100 gouttes)

**Notes :** Recette originale : 110 ml alcool 70%, 380 ml eau déminéralisée, 80-100 gouttes HE

### GRAND AIR

- 40 gouttes HE citron
- 30 gouttes HE eucalyptus radiata
- 30 gouttes HE menthe poivrée

**Version courte :** Un souffle d'air pur sur vos tissus — citron, eucalyptus et menthe pour un linge qui sent le grand dehors.

**Version longue :** Fermez les yeux et respirez. Le citron éclate, l'eucalyptus ouvre l'espace, la menthe arrive comme une brise sur les draps encore chauds du repassage. Grand Air transforme le rituel du linge en une bouffée de nature pure. Vaporisée sur vos tissus, elle dépose un sillage vivifiant et propre qui dure. Comme si vos vêtements avaient séché au vent, quelque part entre la forêt et le ciel.

### SÉRÉNITÉ PURE

- 55 gouttes fragrance lessive fraîche
- 40 gouttes HE lavande vraie

**Version courte :** La douceur de la lavande sur un fond de linge propre — une sérénité textile, du matin au soir.

**Version longue :** Il y a des parfums qui apaisent avant même qu'on les nomme. Sérénité Pure marie la lavande vraie à la fraîcheur du linge propre pour créer un sillage doux et rassurant sur vos tissus. Vaporisée sur draps, oreillers ou vêtements, elle dépose une quiétude subtile qui accompagne les moments calmes. Le genre de parfum qu'on reconnaît sans savoir pourquoi — et qui fait du bien.

### LESSIVE FRAÎCHE

- 80g fragrance lessive fraîche

**Version courte :** L'odeur du linge séché au grand air — comme si la corde à linge avait tout fait le travail.

**Version longue :** Pas de machine, pas de séchoir. Lessive Fraîche capture ce parfum unique du linge qui a séché dehors, bercé par le vent, chauffé par le soleil. Cette odeur simple et vraie qu'on enfouit le nez dedans avant de plier. Vaporisée sur vos tissus, elle recrée ce moment familier et réconfortant — la corde à linge, le ciel bleu, et cette légèreté qu'on ne retrouve nulle part ailleurs.

### LAVANDE

- 80 gouttes HE lavande vraie

**Version courte :** Une eau délicatement parfumée qui dépose sur vos tissus un sillage doux et naturel, du matin au soir.

**Version longue :** Le linge comme une seconde peau. Vaporisée sur vos tissus avant ou après le repassage, cette eau délicatement parfumée prolonge la fraîcheur et laisse sur draps, vêtements et linges de maison un sillage doux et naturel. Parce que la douceur commence dès le matin, au contact du tissu.

---

## LIGNE : SAVON MÉNAGER

### SOUFFLE DE SAPIN

**HEX :** #4A6126
**Nb unités :** 30

**Recette :**
- 2500g saindoux
- 1000g eau déminéralisée
- 340g NaOH
- 15g sel
- 15g argile blanche
- 40g HE sapin

**Notes :** 1 c. à soupe sel = 15g / 1 c. à soupe argile blanche = 15g

**Version courte :** Un savon rustique au parfum de forêt, puissant et authentique, créé pour détacher les tissus et nettoyer la maison avec la force simple du sapin.

**Version longue :** Il y a des produits qui ne cherchent pas à plaire — ils travaillent, tout simplement. Souffle de Sapin est de ceux-là. Son parfum de forêt profonde s'attaque aux taches tenaces, dégraisse les surfaces, détache les tissus avec une efficacité franche et naturelle. Sans artifice, sans compromis. Juste la force tranquille du sapin, mise au service de votre maison.

**Précautions :** Ne pas utiliser sur la peau. Tester sur tissus foncés avant usage. Éviter la laine et la soie.
